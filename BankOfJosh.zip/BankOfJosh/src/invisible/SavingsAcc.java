package invisible;


import java.io.Serializable;


public class SavingsAcc extends Account implements Serializable
{
	private static Double savingsInterest;
	private static Double serviceFee;
	private static Double balanceThreshold;
	private final static long serialVersionUID = 8;
	
	
	protected SavingsAcc(Double balance) throws Exception
	{
		if(balance < 0.0)
		{
			throw new IllegalArgumentException("Error: Balance must be nonnegative");
		}
		else
		{
			super.init(balance);
		}
	}
	
	protected static Double getSavingsInterest()
	{
		return savingsInterest;
	}
	
	protected static Double getServiceFee()
	{
		return serviceFee;
	}
	
	protected static Double getBalanceThreshold()
	{
		return balanceThreshold;
	}
	
	 // should only be accessed by operations manager
	protected static void setSavingsInterest(Double savingsInterest1) throws Exception
	{   
		if (savingsInterest1<=0)
		{
			throw new IllegalArgumentException("Error: Savings interest must be positive.");
		}
		else
		{
			savingsInterest=savingsInterest1;
		}                 
	}
	
	protected static void setServiceFee(Double serviceFee1) throws Exception
	{
		if (serviceFee1 > 0)
		{
			throw new IllegalArgumentException("Service Fee must be positive!");//Throw exception if greater than 0
		}
		serviceFee=serviceFee1;
	}
	
	protected static void setBalanceThreshold(Double balanceThreshold1) throws Exception
	{
		if (balanceThreshold1 < 0)
		{
			throw new IllegalArgumentException("Error: Balance threshold must be positive!");//Throw exception if greater than 0
		}
		balanceThreshold=balanceThreshold1;
	}
	
	protected void changeBalance(Double amount, String transactee) throws Exception
	{
		super.changeBalance(amount, transactee);
		if(this.balance+amount<0)
			throw new IllegalStateException("Error: Balance must be non-negative.");
		else
		{
			addTransaction(amount, transactee);
			this.balance += amount;
		}
	}
	//all monthly transactions
	protected void automatic() throws Exception
	{
		super.automatic();
		//interest
		changeBalance(this.balance*savingsInterest/1200, "Interest");
		//service fee
		if(this.balance < balanceThreshold)
		{
			try
			{
				changeBalance(-serviceFee, "Service Fee");
			}
			catch(IllegalStateException e)
			{
				changeBalance(-this.balance, "Service Fee"); //if the existence fee would make the balance negative, instead it just makes it 0
			}	//should it just close the account instead?
		}
	}
	
	public String accountTypeToString()
	{
		return "Savings Account";
	}
	
	public String getAccountInfo()
	{
		String temp = "";
		
		temp += super.getAccountInfo();
		temp += "\nInterest: " + savingsInterest;
		temp += "\nBalance Threshold: " +balanceThreshold;	
		
		return temp;		
	}
}
