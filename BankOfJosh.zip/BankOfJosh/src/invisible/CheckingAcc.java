package invisible;

import java.io.Serializable;


public class CheckingAcc extends Account implements Serializable
{
	private static Double overdraftThreshold; //negative
	private static Double overdraftFee; //negative
	//global variable keep the same name with other account
	private static Double serviceCharge; //negative
	private static Double serviceThreshold; //cant be lower than overdraft Threshold
	private final static long serialVersionUID = 5;
	 
	
	// no interest for checking account
	
	protected CheckingAcc(Double balance) throws Exception
	{
		if (balance<0.0)
		{
			throw new IllegalStateException("Error: initial balance must be nonnegative");
		}
		else
		{
			super.init(balance);
		}
	}
	protected static Double getOverDraftThreshold()
	{
		return overdraftThreshold;
	}
	protected static Double getOverdraftFee()
	{
		return overdraftFee;
	}
	protected static Double getServiceCharge()
	{
		return serviceCharge;
	}
	protected static Double getServiceThreshold()
	{
		return serviceThreshold;
	}
	protected static void setOverdraftThreshold(Double overdraftThreshold1) throws Exception
	{//throw exception
		if (serviceThreshold != null && overdraftThreshold != null)
		{
			if (overdraftThreshold1 > serviceThreshold)
			{
				throw new IllegalStateException("Error: Overdraft threshold must be less than or equal to service threshold!");
			}
		}
		overdraftThreshold=overdraftThreshold1;
	}
	protected static void setOverdraftFee(Double overdraftFee1) throws Exception
	{//throw exception
		if (overdraftFee1 > 0)
		{
			throw new IllegalStateException("Error: Overdraft fee must be positive!");
		}
		overdraftFee=overdraftFee1;
	}
	protected static void setServiceCharge(Double serviceCharge1) throws Exception
	{//throw exception
		if (serviceCharge1 > 0)
		{
			throw new IllegalStateException("Error: Service charge must be positive!");
		}
		serviceCharge=serviceCharge1;
	}
	protected static void setServiceThreshold(Double serviceThreshold1) throws Exception
	{//throw exception
		if (overdraftThreshold != null && serviceThreshold != null)
		{
			if (serviceThreshold1 > overdraftThreshold)
			{
				throw new IllegalStateException("Error: Service threshold must be greater than or equal to overdraft threshold!");
			}
		}
		serviceThreshold=serviceThreshold1;
	}
	
	protected void changeBalance(Double amount, String transactee) throws Exception
	{
		super.changeBalance(amount,  transactee);
		if(this.balance + amount < overdraftThreshold)
		{
			if(amount >= 0.0)
			{
				this.balance += amount;
				addTransaction(amount, transactee);
			}
			else
			{
				this.balance += overdraftFee;
				addTransaction(overdraftFee, "Overdraft Fee");
				throw new IllegalArgumentException("Error: You have exceed your overdraft threshold and incurred an overdraft fee of $" + -overdraftFee);
			}
		}
		else
		{
			this.balance += amount;
			addTransaction(amount, transactee);
		}
	}

	protected void automatic() throws Exception
	{
		super.automatic();
		if(this.balance < serviceThreshold)
		{
			this.balance += serviceCharge;
			addTransaction(serviceCharge, "Service Charge");
		}
	}
	
	public String accountTypeToString()
	{
		return "Checking Account";
	}
	
	public String getAccountInfo()
	{
		String temp = "";
		temp += super.getAccountInfo();
		return temp;
	}
}
