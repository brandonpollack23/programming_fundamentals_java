package invisible;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class LoanAcc extends Account implements Serializable
{
	private static Double globalInterest; //Reminder: All interest rates should be positive, as the sign of the balance is what determines whether money is gained or lost
	private final Double intRate;
	private final Double minimumMonthly;
	private static Double penaltyFee;
    private Double currentPayment;
    private final static long serialVersionUID = 6;
	
	//Consider when balance reaches zero, the account should be closed
	//Consider customer pay back the loan, need to balance the account
    
    // If the name of static method repeated twice, what's the problem? e.g. setPenaltyFee()
    
    protected LoanAcc(Double balance, Double offsetIntRate, Double minimumMonthly) throws Exception
    {//throw additional exception if loan surpasses loan max
    	if (balance>=0.0 || offsetIntRate + globalInterest <= 0)
    	{
    		throw new IllegalArgumentException("Error: balance must be positive.");
    	}
    	else if (Account.getGlobalLoanMax() > balance)
    	{
    		throw new IllegalStateException("Error: There aren't enough funds to loan this much money!");
    	}
    	else if(minimumMonthly <= 0.0)
    	{
    		throw new IllegalArgumentException("Error: Minimum monthly payment must be positive");
    	}
    	else if(offsetIntRate <= 0)
    	{
    		throw new IllegalArgumentException("Error: Interest offset must be positive");
    	}
    	else
    	{
    		super.init(balance);
    		this.minimumMonthly=minimumMonthly;
        	this.intRate=globalInterest+offsetIntRate;
        	this.creationDate = Data.getToday();
        	this.currentPayment = 0.0;
        	this.transactions = new ArrayList<Transaction>();
    		this.autoTransfers = new HashMap<Account, Double>();
    		setGlobalLoanPool();
    	}
    }
    protected static Double getGlobalInterest()
    {
    	return globalInterest;
    }
    protected Double getIntRate()
    {
    	return intRate;
    }
    protected double getMinimumMonthly()
    {
    	if(-balance < minimumMonthly)
    	{
    		return -this.balance;
    	}
    	else
    	{
    		return minimumMonthly;
    	}
    }
    protected static Double getPenaltyFee()
    {
    	return penaltyFee;
    }
    
    protected Double getCurrentPayment()
    {
    	return this.currentPayment;
    }
    protected static void setGlobalInterest(Double globalInterest1) throws Exception
    {
    	if (globalInterest1 < 0)
    	{
    		throw new IllegalStateException("Error: Global Interest must be positive!");
    	}
    	globalInterest=globalInterest1;	
    }
    protected static void setPenaltyFee(Double penaltyFee1) throws Exception
    {
    	if (penaltyFee1 > 0)
    	{
    		throw new IllegalStateException("Error: Penalty Fee must be positive!");
    	}
    	penaltyFee=penaltyFee1;
    }
    
    protected void changeBalance(Double amount, String transactee) throws Exception
    {
    	super.changeBalance(amount, transactee);
    	if(amount < 0.0)
    	{
    		throw new IllegalArgumentException("Error: You can not withdraw from Loan accounts");
    	}
    	else if(this.balance + amount >= 0.0)
    	{
    		this.isClosed = true;
    		addTransaction(this.balance, transactee);
    		this.balance = 0.0;
    	}
    	else
    	{
    		this.balance += amount;
    		currentPayment += amount;
    		addTransaction(amount, transactee);
    	}
    }
   
	public void automatic() throws Exception
	{
		super.automatic();
		if(currentPayment < this.getMinimumMonthly())
		{
			this.balance += penaltyFee;
			addTransaction(penaltyFee, "Penalty Fee");
		}
		Double interest = this.balance*this.intRate/1200;
		addTransaction(interest, "Interest");
		this.balance += interest;
		currentPayment = 0.0;
	}
	
	public String accountTypeToString()
	{
		return "Loan Account";
	}
	
	public String getAccountInfo()
	{
		String temp = "";
		temp += super.getAccountInfo();
		temp += "\nInterest Rate: " + (intRate);
		temp += "\nMinimum Monthly Payment: " + minimumMonthly;
		temp += "\nPayment This month: " + currentPayment;
		return temp;
	}
}
