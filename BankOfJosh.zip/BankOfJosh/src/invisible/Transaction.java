package invisible;

import java.io.Serializable;
import java.util.GregorianCalendar;


public class Transaction implements Serializable
{
	private final Double amount;
	private GregorianCalendar day;
	private String transactee;
	private Boolean isFlagged;
	private GregorianCalendar twoMonths;
	private final static long serialVersionUID = 9;
	
	protected Transaction(Double amount, String transactee)
	{
		this.amount = amount;
		this.day = Data.getToday();
		this.transactee = transactee;
		isFlagged = false;
		twoMonths = Data.getToday();
		twoMonths.add(GregorianCalendar.MONTH, 2);
	}
	
	protected Double getAmount()
	{
		return this.amount;
	}
	
	protected String getDay()
	{
		return day.toString();
	}
	
	protected Boolean getFlagged()
	{
		return this.isFlagged;
	}
	
	protected String getTransactee()
	{
		return this.transactee;
	}
	
	protected void flag()
	{
		if(Data.getToday().after(twoMonths))
		{
			throw new IllegalStateException("You may only flag transactions within 2 months of making them");
		}
		else
		{
			isFlagged = true;
		}
	}
	
	protected void unFlag()
	{
		isFlagged = false;
	}
	
	public String toString()
	{
		String temp = "";
		temp += "\n \n";
		temp += day.getTime().toString();
		temp += "\n";
		temp += "Latest Date to mark as Flagged: " + twoMonths.getTime().toString();
		temp += "\n \n";
		temp += "Transaction with: " + transactee.toString();
		temp += "\n \n";
		
		temp += "Amount in Transaction: " + amount.toString();
		temp += "\n \n";
		temp += "Marked as fraudulent: " + isFlagged.toString();
		temp += "\n";
		
		temp += "__________________________________________________________";
		return temp;
	}
}
