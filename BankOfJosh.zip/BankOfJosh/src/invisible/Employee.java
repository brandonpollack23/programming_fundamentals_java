package invisible;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;

import visible.AccountManager;
import visible.Accountant;
import visible.Auditor;
import visible.OperationsManager;
import visible.Role;
import visible.Teller;
//import java.util.Date;
//import java.util.Random;
//import invisible.Exceptions.*;

public class Employee implements Teller, AccountManager, Accountant, Auditor, OperationsManager, Serializable
{
	private Role role;
	private final Integer ssn;
	private Account activeAccount;
	private Customer customer;
	private static Double tellerCharge;
	private final static long serialVersionUID = 2;
	
	public Employee(Role role, Integer ssn) throws IllegalArgumentException
	{
		if (Data.getEmployee(ssn) != null)
		{
			throw new IllegalArgumentException("That employee already exists in the system");  //this needs to be caught in the UI and print "This employee already works at this bank"
		}
		else
		{
			this.role = role;
			this.ssn = ssn;
		}
	}
	
	public Double getTellerCharge()
	{
		return tellerCharge;
	}
	
	public void setTellerCharge(Double tellerCharge1)
	{
		tellerCharge = tellerCharge1;
	}
	
	public Role getRole() 
	{
		return role;
	}

	public Account getAccount() 
	{
		return activeAccount;
	}

	public Customer getCustomer() 
	{
		return customer;
	}

	public void sendNotice(Customer cust, String notice) 
	{
		cust.addNotice(notice);		
	}

	
	public ArrayList<Customer> getCustomerList() 
	{
		return Data.getCustomerList(); 
	}

	
	public void advanceTime()
	{
		GregorianCalendar temp = Data.getToday();
		temp.add(Calendar.MONTH, 1);
		Data.setToday(temp);
		ArrayList<Account> allAccounts = Data.getAccountList();
		for (int i = 0; i < allAccounts.size(); i++)
		{
			try
			{
				allAccounts.get(i).automatic();
				//Data.addAccount(allAccounts.get(i));
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
	}

	
	public void setSavingsInterestRate(Double interest) throws Exception
	{
		SavingsAcc.setSavingsInterest(interest);	
	}

	
	public void setSavingsServiceFee(Double service) throws Exception 
	{
		SavingsAcc.setServiceFee(service);
	}

	
	public void setSavingsBalanceThreshold(Double thresh) throws Exception 
	{
		SavingsAcc.setBalanceThreshold(thresh);
	}

	
	public void setCDGlobalInterestRates(Double[] intRates) throws Exception 
	{
		CDAcc.setPossibleIntRates(intRates);	
	}

	public void setCDcloseThreshold(Double thresh) throws Exception
	{
		CDAcc.setCloseThreshold(thresh);
		
	}

	
	public void setCheckingServiceCharge(Double service) throws Exception
	{
		CheckingAcc.setServiceCharge(service);
	}

	
	public void setCheckingOverdraftFee(Double fee) throws Exception
	{
		CheckingAcc.setOverdraftFee(fee);		
	}

	
	public void setCheckingOverdraftThreshold(Double thresh) throws Exception
	{
		CheckingAcc.setOverdraftThreshold(thresh);		
	}

	
	public void setLoanGlobalInterest(Double interest) throws Exception 
	{
		LoanAcc.setGlobalInterest(interest);	
	}

	
	public void setLoanPenaltyFee(Double fee) throws Exception 
	{
		LoanAcc.setPenaltyFee(fee);	
	}

	
	public void setLOCCreditLimit(Double limit) throws Exception 
	{
		if (activeAccount instanceof LOCAcc)
			{
				((LOCAcc) activeAccount).setCreditLimit(limit);
			}
	}

	
	public void setLOCGlobalInterest(Double interest) 
	{
		LOCAcc.setGlobalInterest(interest);		
	}

	
	public void setLOCPenaltyFee(Double fee) throws Exception 
	{
		LOCAcc.setPenaltyFee(fee);
	}

	public ArrayList<Transaction> getTransactions() 
	{
		return activeAccount.getTransactions();
	}

	public String getTransactionInfo(Transaction trans)
	{
		return trans.toString();
	}
		
	public void accessAccount(Integer accNum) throws Exception
	{
		this.activeAccount = Data.getAccount(accNum);
		if(activeAccount == null)
		{
			throw new IllegalArgumentException("There is no account registered with that number.");
		}
	}
	
	public Integer getCustomerSSN()
	{
		return customer.getSSN();
	}
	
	public Integer getAccountNumber() 
	{
		return activeAccount.getAccNum();
	}

	
	public Boolean isClosed() 
	{
		return activeAccount.isClosed();
	}

	
	public GregorianCalendar getCreationDate() 
	{
		return activeAccount.getCreationDate();
	}
	
	public void addCustomer(String firstName, String lastName, Integer ssn, Boolean isEmployee, Account firstAccount) throws Exception 
	{
		Customer newCustomer = new Customer(firstName, lastName, ssn, isEmployee);
		Data.addCustomer(newCustomer);
		newCustomer.addAccount(firstAccount);
		firstAccount.setOwner(newCustomer);
	}
	
	public Double getGlobalLoanCap() 
	{
		return Account.getGlobalLoanCap();
	}
	
	public void setGlobalLoanCap(Double newCap) throws Exception
	{
		Account.setGlobalLoanCap(newCap);
	}
	
	public Double getGlobalLoanPool() 
	{
		return Account.getGlobalLoanPool();
	}
	
	public Double getBalance() 
	{
		return activeAccount.getBalance();
	}
	
	public Double getBalanceThreshold() 
	{
		return SavingsAcc.getBalanceThreshold();
	}
	
	public void setCDCloseThreshold(Double thresh) throws Exception
	{
		CDAcc.setCloseThreshold(thresh);
	}
	
	public void overturnTransaction(Integer transIndex) 
	{
		activeAccount.overturnTransaction(transIndex);
	}

	
	public Boolean isEmployee() 
	{
		return customer.isEmployee();
	}
	
	public Double getSavingsInterestRate()
	{
		return SavingsAcc.getSavingsInterest();
	}

	
	public Double getSavingsServiceFee()
	{
		return SavingsAcc.getServiceFee();
	}
	
	public Double getCheckingServiceCharge() 
	{
		return CheckingAcc.getServiceCharge();
	}

	
	public Double getCheckingOverdraftFee()
	{
		return CheckingAcc.getOverdraftFee();
	}

	
	public Double getCheckingOverdraftThreshold()
	{
		return CheckingAcc.getOverDraftThreshold();
	}

	
	public Double getLoanGlobalInterest() 
	{
		return LoanAcc.getGlobalInterest();
	}

	
	public Double getLoanPenaltyFee() 
	{
		return LoanAcc.getPenaltyFee();
	}

	
	public Double getLOCGlobalInterest() 
	{
		return LOCAcc.getGlobalInterest();
	}

	
	public CDAcc createCDAcc(Double initialBalance, Integer length) throws Exception
	{
		Account temp = new CDAcc(initialBalance, length);
		Data.addAccount(temp);
		return (CDAcc) temp;
	}

	
	public CheckingAcc createCheckingAcc(Double initialBalance) throws Exception 
	{
		Account temp = new CheckingAcc(initialBalance);
		Data.addAccount(temp);	
		return (CheckingAcc) temp;
	}

	
	public LoanAcc createLoanAcc(Double initalLoan, Double interestOffset, Double minimumMonthly) throws Exception
	{
		Account temp = new LoanAcc(-initalLoan, interestOffset, minimumMonthly); //need to do minimum monthly
		Data.addAccount(temp);
		return (LoanAcc) temp;
	}

	
	public LOCAcc createLOCAcc(Double creditLimit, Double interestOffset) throws Exception
	{
		Account temp = new LOCAcc(-creditLimit, interestOffset);
		Data.addAccount(temp);
		return (LOCAcc) temp;
	}

	
	public SavingsAcc createSavingsAcc(Double initialBalance) throws Exception 
	{
		Account temp = new SavingsAcc(initialBalance);
		Data.addAccount(temp);
		return (SavingsAcc) temp;
	}
	
	public Customer getOwner()
	{
		return activeAccount.getOwner();
	}
	
	public Integer getCDLength() 
	{
		if (activeAccount instanceof CDAcc)
		{
			return ((CDAcc) activeAccount).getCDLength();
		}
		else return -1;
	}

	
	public GregorianCalendar getCDMatureDate() 
	{
		if (activeAccount instanceof CDAcc)
		{
			return ((CDAcc) activeAccount).getMatureDate();
		}
		else return null;
	}

	
	public Double getLoanAccountInterest()
	{
		if (activeAccount instanceof LoanAcc)
		{
			return LoanAcc.getGlobalInterest() + ((LoanAcc) activeAccount).getIntRate(); //interest offset plus global interest
		}
		else return -1.00;
	}

	
	public Double getLoanMinimumMonthly() 
	{
		if (activeAccount instanceof LoanAcc)
		{
			return ((LoanAcc) activeAccount).getMinimumMonthly();
		}
		else return null;
	}

	
	public Double getLOCCreditLimit() 
	{
		if (activeAccount instanceof LOCAcc)
		{
			return ((LOCAcc) activeAccount).getCreditLimit();
		}
		else return (double) -1;
	}

	
	public Double getLOCInterest()
	{
		if (activeAccount instanceof LOCAcc)
		{
			return LOCAcc.getGlobalInterest() + ((LOCAcc) activeAccount).getInterestOffset();
		}
		else return (double) -1;
	}
	
	public Double getSavingsBalanceThreshold()
	{
		return SavingsAcc.getBalanceThreshold();
	}

	
	public Double getCDCloseThreshold() 
	{
		return CDAcc.getBalanceThreshold();
	}

	
	public Double getCheckingOverDraftThreshold() 
	{
		return CheckingAcc.getOverDraftThreshold();
	}

	
	public Double getCheckingServiceThreshold() 
	{
		return CheckingAcc.getServiceThreshold();
	}

	
	public Double getLOCPenaltyFee() 
	{
		return LOCAcc.getPenaltyFee();
	}
	
	public void setAutoTransaction(Integer accNum, Double amount) throws Exception 
	{
		activeAccount.addAutoTransfer(Data.getAccount(accNum), amount);
	}

// Any charge due to service should not use setBalance. Instead, use setBalanceforService
	public void chargeService() 
	{
		activeAccount.chargeService(tellerCharge, "Teller Charge");
	}

	
	public Double getLOCBalanceSum() 
	{
		ArrayList<Account> temp = Data.getAccountList();
		Double sum = (double) 0;
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp.get(i) instanceof LOCAcc)
			{
				sum += temp.get(i).getBalance();
			}
		}
		return -sum;
	}

	
	public Double getLOCCreditLimitSum() 
	{
		ArrayList<Account> temp = Data.getAccountList();
		Double sum = (double) 0;
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp.get(i) instanceof LOCAcc)
			{
				sum += ((LOCAcc) temp.get(i)).getCreditLimit();
			}
		}
		return sum;
	}

	
	public Double getTotalCheckingMoney() 
	{
		ArrayList<Account> temp = Data.getAccountList();
		Double sum = (double) 0;
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp.get(i) instanceof CheckingAcc)
			{
				sum += temp.get(i).getBalance();
			}
		}
		return sum;
	}

	
	public Double getTotalSavingsMoney() 
	{
		ArrayList<Account> temp = Data.getAccountList();
		Double sum = (double) 0;
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp.get(i) instanceof SavingsAcc)
			{
				sum += temp.get(i).getBalance();
			}
		}
		return sum;
	}

	
	public Double getTotalLoanSum()
	{
		ArrayList<Account> temp = Data.getAccountList();
		Double sum = (double) 0;
		for (int i = 0; i < temp.size(); i++)
		{
			if (temp.get(i) instanceof LoanAcc)
			{
				sum += temp.get(i).getBalance();
			}
		}
		return -sum;
	}


	public HashMap<Integer, Double> getCDGlobalInterestRates() 
	{
		return CDAcc.getCDPossibleRates();
	}

	public void changeBalance(Double amount) throws Exception
	{
		activeAccount.changeBalance(amount, "Bank");
	}
	
	public void accessCustomer(Integer ssn)
	{
		customer = Data.getCustomer(ssn);
	}
	
	public String getOwnerName()
	{
		return activeAccount.getOwner().getFirstName() + " " + activeAccount.getOwner().getLastName();
	}
	
	public Double getCheckingOverDraftFee()
	{
		return CheckingAcc.getOverdraftFee();
	}
	
	public Double getMinimumMonthly()
	{
		if(activeAccount instanceof LOCAcc)
		{
			return ((LOCAcc) activeAccount).getMinimumMonthly();
		}
		else if(activeAccount instanceof LoanAcc)
		{
			return ((LoanAcc) activeAccount).getMinimumMonthly();
		}
		else
		{
			throw new IllegalStateException("Active Account must be either LOC or Loan");
		}
	}
	
	public Double getCurrentPayment()
	{
		if(activeAccount instanceof LOCAcc)
		{
			return ((LOCAcc) activeAccount).getCurrentPayment();
		}
		else if(activeAccount instanceof LoanAcc)
		{
			return ((LoanAcc) activeAccount).getCurrentPayment();
		}
		else
		{
			throw new IllegalStateException("Active Account must be either LOC or Loan");
		}
	}
	
	public Integer getSSN()
	{
		return this.ssn;
	}
	
	public String getAccountType()
	{
		return activeAccount.accountTypeToString();
	}
	
	public String getAutoTransactions()
	{
		return activeAccount.getAutoTransactions();
	}
	
	public void removeAutoTransaction(Integer accNum)
	{
		activeAccount.removeAutoTransfer(Data.getAccount(accNum));
	}
	
	public String getAccountInfo()
	{
		return activeAccount.getAccountInfo();
	}
	
	public void addAccount(Account a) throws Exception
	{
		a.setOwner(customer);
		customer.addAccount(a);
		Data.addAccount(a);
	}
	
	public ArrayList<Account> getAccountList()
	{
		return Data.getAccountList();
	}
	
	public String getAccountListToString()
	{
		ArrayList<Account> temp = getAccountList();
		String rtemp = "";
		for (int i = 0; i < temp.size(); i++)
		{
			rtemp += (i + 1) + ") ";
			rtemp += temp.get(i).toString() + "\n";
		}
		return rtemp;
	}

	public void setCheckingServiceThreshold(Double thresh) throws Exception
	{
		CheckingAcc.setServiceThreshold(thresh);
	}

	public void setLOCMinimumFixed(Double minFixed) throws Exception
	{
		LOCAcc.setMinimumFixed(minFixed);
	}

	public void setLOCMinimumPercent(Double minPercent) throws Exception 
	{
		LOCAcc.setMinimumPercent(minPercent);
	}

	public Double getLOCMinimumFixed() 
	{
		return LOCAcc.getMinimumFixed();
	}

	public Double getLOCMinimumPercent() 
	{
		return LOCAcc.getMinimumPercent();
	}
	
	public void accessAccount(Account a)
	{
		activeAccount = a;
	}
	
	public void addEmployee(Integer ssn, Role role)
	{
		Data.addEmployee(new Employee(role, ssn));
	}
}
