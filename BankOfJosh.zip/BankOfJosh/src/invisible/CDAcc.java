package invisible;
//these all need a Mature date date, instead of using double cdLength in the constructor, just have an end date, the actual params that get put into that will be taken care of
//by the UI main when the date is selected from a menu (hard coded) so change it to an int or something

//also we dont use double we use Double, it is more usefule and supports type restriciton

// need to have check in the constructor of ALL accounts for duplicate account number, throw an exception that I can catch at account creation and generate a new number
//for that exception make up a name like AccountExistsException and add a class for it in the Exceptions.java file we have

import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.HashMap;


//import java.util.*;
public class CDAcc extends Account implements Serializable
{
	//greater than globally-set minimum balance
	//private static double closeThreshold;
	 private final Integer cdLength; //length in months 
	 private final GregorianCalendar matureDate;
	 //it should be initialized in other places
	 private static HashMap<Integer, Double> cdPossibleRates;
	 private final Double intRate; //interest rate why it's final?
	 private Boolean isMature; //makes it easier to check
	 private static Double balanceThreshold;
	 private Integer monthsLeft;
	 private final static long serialVersionUID = 4;
	 
	 protected CDAcc(Double balance, Integer cdLength) throws Exception
	 { //also needs exception if balance is less than close threshold
		 if (!(cdPossibleRates.containsKey(cdLength)))
		 {
			 throw new IllegalStateException("Error: Invalid CD length"); 
		 }
		 else if(balance < balanceThreshold)
		 {
			 throw new IllegalArgumentException("Error: Initial balance must be equal to or greater than the close threshold");
		 }
		 {
			 super.init(balance);
			 this.cdLength=cdLength;
			 intRate = cdPossibleRates.get(cdLength);
			 matureDate = Data.getToday();
			 matureDate.add(GregorianCalendar.MONTH, cdLength);
			 monthsLeft = new Integer(cdLength);
			 isMature=false;                             // set false at the beginning
		 }
	 }
	 
	 protected Integer getCDLength()
	 {
		 return cdLength;
	 }
	 
	 protected GregorianCalendar getMatureDate()
	 {
		 return matureDate;
	 }
	 
	 protected static HashMap<Integer,Double> getCDPossibleRates()
	 {
		 return cdPossibleRates;
	 }
	 
	 protected Double getIntRate()
	 {
		 return intRate;
	 }
	 
	 protected Boolean getIsMature()
	 {
		 return this.isMature;
	 }
	 
	 protected static Double getBalanceThreshold()
	 {
		 return balanceThreshold;
	 }
	 
	 protected Integer getMonthsLeft()
	 {
		 return this.monthsLeft;
	 }
	 
	 protected void changeBalance(Double amount, String transactee) throws Exception //Note: if withdraw triggers close, only withdraw enough to close account? or shoudl customer get money back? thoughts?
	 {
		 super.changeBalance(amount, transactee); //Thought, though this isnt mentioned in the instructions, i would have thought that you can't put money into a CD, that would defeat the purpose of the length, and it is like a reverse loan
		 if(!(isMature))
		 {
			 if(amount < 0.0)
			 {
				 Double penalty = -6*this.balance*this.intRate/1200;
				 this.balance += penalty;
				 addTransaction(penalty, "Penalty");
				 System.out.println("You have withdrawn early an incurred a penalty fee of $" + -penalty);
			 }
		 }
		 if(this.balance + amount < balanceThreshold)
		 {
			 this.isClosed = true;
		 }
		 this.balance += amount;               //need else here?
		 addTransaction(amount, transactee);
	 }
	
	protected static void setPossibleIntRates(Double[] newRates) throws Exception
	{
		if(newRates[0] <= SavingsAcc.getSavingsInterest())
		{
			throw new IllegalArgumentException("Error: interest rates must be at least higher than savings interest rates");
		}
		else
		{
			for(int i = 0; i < 5; i++)
			{
				if(newRates[i] >= newRates[i+1])
				{
					throw new IllegalArgumentException("Error: interest rates must increase as cd length increases");
				}
			}
		}
		HashMap<Integer, Double> newPossibleRates = new HashMap<Integer, Double>();
		newPossibleRates.put(6, newRates[0]);
		for(Integer i = 1; i < 6; i++)
		{
			newPossibleRates.put(i*12, newRates[i]);  //Note:the first CD length is from 6 months not 12 months
		}
		cdPossibleRates = newPossibleRates;
	}
	
	protected static void setCloseThreshold(Double thres) throws Exception
	{
		if(thres < 0.0)
		{
			throw new IllegalArgumentException("Error: Threshold must be positive");
		}
		balanceThreshold = thres;
	}
	
	protected void automatic() throws Exception
	{
		super.automatic();
		if(!(this.isMature))
		{
			//interest
			changeBalance(this.balance*this.intRate/1200, "Interest");
			
			//months left
			this.monthsLeft --;
		}
		if(this.monthsLeft == 0)
		{
			this.isMature = true;
		}
	}	
	
	public String accountTypeToString()
	{
		return "Certificate Deposit Account";
	}
	
	public String getAccountInfo()
	{
		String temp = "";
		
		temp += super.getAccountInfo();
		temp += "\nCD Length: " + cdLength;
		temp += "\nMature Date: " + matureDate;
		if (!isMature) temp += "\nMonths Until Mature: " + monthsLeft;
		temp += "\nIs Mature? " + isMature;
		return temp;
	}
}
