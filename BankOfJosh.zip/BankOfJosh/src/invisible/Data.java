package invisible;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Random;

import visible.Role;


public enum Data
{
	DATA;
	private HashMap<Integer, Account> accounts;
	private HashMap<Integer, Customer> customers;
	private HashMap<Integer, Employee> employees;
	private GregorianCalendar today;
	private Random random;
	
	Data()
	{
		accounts = new HashMap<Integer, Account>();
		customers = new HashMap<Integer, Customer>();
		employees = new HashMap<Integer, Employee>();
		today = new GregorianCalendar();
		random = new Random();
	}
	
	public static void save()
	{
		System.out.println("Saving data...");
		try
		{
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(System.getProperty("user.dir") + "\\data.txt"));
			oos.writeObject(DATA.accounts);
			oos.writeObject(DATA.customers);
			oos.writeObject(DATA.employees);
			oos.writeObject(DATA.today);
			oos.writeObject(DATA.random);
			oos.close();
		}
		catch(Exception a)
		{
			try
			{
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(System.getProperty("user.dir") + "\\data.txt"));
				oos.writeObject(DATA.accounts);
				oos.writeObject(DATA.customers);
				oos.writeObject(DATA.employees);
				oos.writeObject(DATA.today);
				oos.writeObject(DATA.random);
				oos.close();
			}
			catch(Exception b)
			{
				try
				{
					ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(System.getProperty("user.dir") + "\\data.txt"));
					oos.writeObject(DATA.accounts);
					oos.writeObject(DATA.customers);
					oos.writeObject(DATA.employees);
					oos.writeObject(DATA.today);
					oos.writeObject(DATA.random);
					oos.close();
				}
				catch(Exception c)
				{
					System.out.println("Save failed!");
					c.printStackTrace();
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public static void load()
	{
		System.out.println("Loading data...");
		try
		{
			ObjectInputStream oos = new ObjectInputStream(new FileInputStream(System.getProperty("user.dir") + "\\data.txt"));
			DATA.accounts = (HashMap<Integer, Account>) oos.readObject();
			DATA.customers = (HashMap<Integer, Customer>) oos.readObject();
			DATA.employees = (HashMap<Integer, Employee>) oos.readObject();
			DATA.today = (GregorianCalendar) oos.readObject();
			DATA.random = (Random) oos.readObject();
			oos.close();
		}
		catch(Exception a)
		{
			try
			{
				ObjectInputStream oos = new ObjectInputStream(new FileInputStream(System.getProperty("user.dir") + "\\data.txt"));
				DATA.accounts = (HashMap<Integer, Account>) oos.readObject();
				DATA.customers = (HashMap<Integer, Customer>) oos.readObject();
				DATA.employees = (HashMap<Integer, Employee>) oos.readObject();
				DATA.today = (GregorianCalendar) oos.readObject();
				DATA.random = (Random) oos.readObject();
				oos.close();
			}
			catch(Exception b)
			{
				try
				{
					ObjectInputStream oos = new ObjectInputStream(new FileInputStream(System.getProperty("user.dir") + "\\data.txt"));
					DATA.accounts = (HashMap<Integer, Account>) oos.readObject();
					DATA.customers = (HashMap<Integer, Customer>) oos.readObject();
					DATA.employees = (HashMap<Integer, Employee>) oos.readObject();
					DATA.today = (GregorianCalendar) oos.readObject();
					DATA.random = (Random) oos.readObject();
					oos.close();
				}
				catch(Exception c)
				{
					System.out.println("Load failed!");
				}
			}
		}
	}
	
	public static void clearAllData()
	{
		DATA.accounts.clear();
		DATA.customers.clear();
		DATA.employees.clear();
		Data.save();
	}
	
	public static Customer getCustomer(Integer ssn)
	{
		return DATA.customers.get(ssn);
	}
	
	protected static Account getAccount(Integer accNum)
	{
		return DATA.accounts.get(accNum);
	}
	
	public static Employee getEmployee(Integer ssn)
	{
		return DATA.employees.get(ssn);
	}
	
	public static GregorianCalendar getToday()
	{
		return (GregorianCalendar) DATA.today.clone();
	}
	
	protected static ArrayList<Account> getAccountList()
	{
		return new ArrayList<Account>(DATA.accounts.values());
	}
	
	protected static void addCustomer(Customer c)
	{
		DATA.customers.put(c.getSSN(), c);
	}
	
	protected static void addAccount(Account a)
	{
		DATA.accounts.put(a.getAccNum(), a);
	}
	
	public static void addEmployee(Employee e)
	{
		DATA.employees.put(e.getSSN(), e);
	}
	
	protected static void setToday(GregorianCalendar today)
	{
		DATA.today = (GregorianCalendar)today.clone();
	}
	
	protected static ArrayList<Customer> getCustomerList()
	{
		return new ArrayList<Customer>(DATA.customers.values());
	}
	
	protected static Integer getNewAccNum()
	{
		Integer rand = 0;
		rand = DATA.random.nextInt(1000000000) + 1;
		while(DATA.accounts.containsKey(rand))
		{
			rand = DATA.random.nextInt(1000000000) + 1;
		}
		return rand;
	}
	
	public static void initialize()
	{
		try
		{
			SavingsAcc.setSavingsInterest(1.0);
			SavingsAcc.setServiceFee(-1.0);
			SavingsAcc.setBalanceThreshold(100.0);
			LOCAcc.setGlobalInterest(1.0);
			LOCAcc.setMinimumFixed(-100.0);
			LOCAcc.setMinimumPercent(10.0);
			LOCAcc.setPenaltyFee(-10.0);
			LoanAcc.setGlobalInterest(1.0);
			LoanAcc.setPenaltyFee(-10.0);	
			CheckingAcc.setOverdraftFee(-10.0);
			CheckingAcc.setOverdraftThreshold(-100.0);
			CheckingAcc.setServiceCharge(-1.0);
			CheckingAcc.setServiceThreshold(100.0);
			CDAcc.setCloseThreshold(100.0);
			CDAcc.setPossibleIntRates(new Double[]{2.0,3.0,4.0,5.0,6.0,7.0});
			Data.addEmployee(new Employee(Role.TELLER, 1));
			Data.addEmployee(new Employee(Role.ACCOUNT_MANAGER, 2));
			Data.addEmployee(new Employee(Role.ACCOUNTANT, 3));
			Data.addEmployee(new Employee(Role.AUDITOR, 4));
			Data.addEmployee(new Employee(Role.OPERATIONS_MANAGER, 5));
			SavingsAcc sA = new SavingsAcc(1000.0);
			Data.addAccount(sA);
			Customer c = new Customer("John", "Doe", 10, false);
			Data.addCustomer(c);
			SavingsAcc sA2 = new SavingsAcc(1000.0);
			Data.addAccount(sA2);
			c.addAccount(sA);
			sA.setOwner(c);
			c.addAccount(sA2);
			sA2.setOwner(c);
			Data.getEmployee(5).setTellerCharge(-10.0);
			Account.globalLoanPool = 0.0;
			Account.setGlobalLoanCap(-10000.0);
			System.out.println("1st account number is: " + sA.getAccNum());
			System.out.println("2nd account number is: " + sA2.getAccNum());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("Initialization failed!");
			e.printStackTrace();
		}
	}
}
