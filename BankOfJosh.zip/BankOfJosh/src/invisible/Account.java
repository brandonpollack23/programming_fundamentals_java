package invisible;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

public abstract class Account implements Serializable //Note to self: all numbers should use the correct sign, so all charges are negative
{
	protected Integer accNum;
	protected Double balance;
	protected Customer owner;
	protected ArrayList<Transaction> transactions;
	protected Boolean isClosed;
//	protected Double closeThreshold;
	protected GregorianCalendar creationDate; //using this because too annoying to add time to a Date
	protected HashMap<Account, Double> autoTransfers; //a list of every account we send money to automatically, including this one, and the value
	protected static Double globalLoanCap; //maximum money bank can invest in loans and loc accounts
	protected static Double globalLoanPool; //money bank has invested in loans and loc accounts
	private final static long serialVersionUID = 3;
	
	protected void init(Double balance)
	{
		accNum = Data.getNewAccNum();
		this.balance = balance;
		owner = null;
		transactions = new ArrayList<Transaction>();
		isClosed = false;
		creationDate = Data.getToday();
		autoTransfers = new HashMap<Account, Double>();
		globalLoanPool = (double) 0;
	}
	
	protected static Double getGlobalLoanCap()
	{
		return globalLoanCap;
	}
	
	protected static void setGlobalLoanCap(Double cap) throws Exception
	{
		if(cap > globalLoanPool) //if cap is less negative
		{
			throw new IllegalArgumentException("Loan cap must be equal to or greater than loan pool");
		}
		globalLoanCap = cap;
	}
	
	protected static Double getGlobalLoanPool()
	{
		return globalLoanPool;
	}
	
	protected static Double getGlobalLoanMax()
	{
		return globalLoanCap - globalLoanPool;
	}
	
	protected static void setGlobalLoanPool()
	{
		Double loanPool = 0.0;
		ArrayList<Account> temp = new ArrayList<Account>();
		temp = Data.getAccountList();
		Account a;
		for(int i = 0; i < temp.size(); i++)
		{
			a = temp.get(i);
			if(a instanceof LOCAcc && !(a.isClosed()))
			{
				loanPool += ((LOCAcc) a).getCreditLimit(); //credit limit should be negative
			}
			else if(a instanceof LoanAcc && !(a.isClosed()))
			{
				loanPool += a.getBalance();
			}
		}
		globalLoanPool = loanPool;
	}
	
	protected Integer getAccNum() 
	{
		return this.accNum;
	}

	protected Double getBalance() 
	{
		return this.balance;
	}

	protected Customer getOwner() 
	{
		return this.owner;
	}

	protected ArrayList<Transaction> getTransactions() 
	{
		return this.transactions;
	}

	protected Boolean isClosed() 
	{
		return this.isClosed;
	}
	
	protected void setClosed(Boolean isClosed)
	{
		this.isClosed=isClosed;
	}

	protected GregorianCalendar getCreationDate() 
	{
		return this.creationDate;
	}

	protected HashMap<Account, Double> getAutoTransfers() 
	{
		return this.autoTransfers;
	}

	protected void changeBalance(Double amount, String transactee) throws Exception
	{
		if (isClosed())
		{
			throw new IllegalStateException("Error: This account is closed"); 
		}	
	}
	
	protected void setOwner(Customer owner) throws Exception
	{
		if(Data.getCustomerList().contains(owner))
		{
			this.owner = owner;
		}
		else
		{
			throw new IllegalArgumentException("Error: Owner must be a registered customer");
		}
	}
	

	protected void addTransaction(Double amount, String transactee)
	{
		transactions.add(new Transaction(amount, transactee));
	}
	
	public void addAutoTransfer(Account acc, Double amount) throws Exception
	{
		if(acc == this)
		{
			throw new IllegalArgumentException("Error: Account cannot transfer with itself");
		}
		else if(amount <= 0.0)
		{
			throw new IllegalArgumentException("Error: transfer amount must be positive");
		}
		autoTransfers.put(acc, amount);
	}
	
	protected void chargeService(Double amount, String transactee)
	{
		this.balance += amount;
		addTransaction(amount, transactee);
	}
	
	protected void automatic() throws Exception
	{
		if(this.isClosed)
		{
			throw new IllegalStateException("Error: This account is closed");
		}
		for(Map.Entry<Account, Double> e: this.autoTransfers.entrySet())
		{
			this.changeBalance(-e.getValue(), e.getKey().getAccNum().toString());
			e.getKey().changeBalance(e.getValue(), this.getAccNum().toString());
		}
	}
	
	protected void overturnTransaction(Integer transIndex)
	{
		this.balance -= transactions.get(transIndex).getAmount();
		transactions.remove(transIndex);
	}
	
	public String transactionsToString()
	{
		String temp = "";
		for (int i = 0; i < transactions.size(); i++)
		{
			temp += i+1 + ")";
			temp += transactions.get(i).toString();
		}
		return temp;
	}
	
	protected void removeAutoTransfer(Account a)
	{
		autoTransfers.remove(a);
	}
	
	public abstract String accountTypeToString();
	
	public String getAccountInfo()
	{
		String temp = "";
		temp += "Account Number: " + accNum;
		temp += "\nOwner: " + owner.getLastName() + ", " + owner.getFirstName();
		temp += "\nIs closed? " + isClosed;
		temp += "\nCreation Date: " + creationDate.getTime().toString();
		temp += "\nBalance: " + Math.abs(balance);
		return temp;
	}
	
	public String getAutoTransactions()
	{
		String autoTrans = "";
		int i = 0;
		for(Map.Entry<Account, Double> e: this.autoTransfers.entrySet())
		{
			i++;
			autoTrans += i + ". Account #: " + e.getKey().getAccNum() + ", Account Type: " + e.getKey().accountTypeToString() + ", Current Autotransfer Amount: " + e.getValue() + "\n";
		}
		return autoTrans;
	}
	
	public String toString()
	{
		String temp = "";
		temp += getAccNum();
		temp += ": " + accountTypeToString();
		Integer flaggedTransactions = 0;
		for (int i = 0; i < transactions.size(); i++)
		{
			if(transactions.get(i).getFlagged()) flaggedTransactions++;
		}
		temp += ", flagged transactions: " + flaggedTransactions;
		temp += ", Is Owner Employee: " + owner.isEmployee();
		return temp;
	}
}
