package invisible;

import java.io.Serializable;


//need a get balance (returns negative value)
public class LOCAcc extends Account implements Serializable
{
	private Double creditLimit;
	private static Double globalInterest;
	private Double interestOffset;
	private static Double minimumFixed;
	private static Double minimumPercent;
	private Double minimumMonthly; //this is the actual minimum amount that needs to be paid that month, based on the smaller of the two payments at the beginning of the month
	private static Double penaltyFee;
	private Double intRate;
	private Double currentPayment;
	private final static long serialVersionUID = 7;
	
	protected LOCAcc(Double creditLimit, Double interestOffset) throws Exception
	{ //throw exceptions including one for credit limit surpassing loan max
		if (creditLimit > Account.getGlobalLoanMax())
		{
			throw new IllegalStateException("Error: There aren't enough funds to have this high of a credit limit!");
		}
		else if (creditLimit >= 0)
		{
			throw new IllegalArgumentException("Error: Credit limit must be a positive value!");
		}
		else if (interestOffset <= 0)
		{
			throw new IllegalStateException("Error: Offset interest must be a positive value!");
		}
		else
		{
			super.init(balance);
			this.creditLimit = creditLimit; //throw exception
			this.interestOffset = interestOffset; //throw exception
			this.intRate=globalInterest+interestOffset;
			this.minimumMonthly = 0.0;
			this.currentPayment = 0.0;
			setGlobalLoanPool();
		}
	}
	protected Double getCreditLimit()
	{
		return creditLimit;
	}
	protected static Double getGlobalInterest()
	{
		return globalInterest;
	}
	protected Double getInterestOffset()
	{
		return interestOffset;
	}
	protected static Double getMinimumFixed()
	{
		return minimumFixed;	
	}
	protected static Double getMinimumPercent()
	{
		return minimumPercent;
	}
	protected static Double getPenaltyFee()
	{
		return penaltyFee;
	}
	protected Double getIntRate()
	{
		return this.intRate;
	}
	protected Double getMinimumMonthly()
	{
		return this.minimumMonthly;
	}
	protected Double getCurrentPayment()
	{
		return this.currentPayment;
	}
	protected void setCreditLimit(Double creditLimit) throws Exception
	{//throw exception
		if (creditLimit > 0)
		{
			throw new IllegalStateException("Error: Credit limit must be a positive value!");
			
		}
		this.creditLimit=creditLimit;
	}
	protected static void setGlobalInterest(Double globalInterest1)
	{
		if (globalInterest1 <= 0.0)
		{
			throw new IllegalStateException("Error: Global interest must be a positive value!");
		}
		globalInterest=globalInterest1;
	}
	protected void setInterestOffset(Double interestOffset) throws IllegalArgumentException
	{
		if(interestOffset <= 0.0)
		{
			throw new IllegalArgumentException("Error: Offset interest must be positive");
		}
		else
		{
			this.interestOffset=interestOffset;
		}
	}
	protected static void setMinimumFixed(Double minimumFixed1) throws Exception//if these are changed mid-month, they will not affect the actual minimumMonthly until the next month
	{//throw exception
		if (minimumFixed1 > 0)
		{
			throw new IllegalArgumentException("Error: Minimum fixed payment must be a positive value!");
		}
		minimumFixed=minimumFixed1;
	}
	protected static void setMinimumPercent(Double minimumPercent1) throws Exception
	{//throw exception
		if (minimumPercent1 < 0)
		{
			throw new IllegalArgumentException("Error: Minimum percentage payment must be a positive value!");
		}
		minimumPercent=minimumPercent1;
	}
	protected static void setPenaltyFee(Double penaltyFee1) throws Exception
	{//throw exception
		if (penaltyFee1 > 0)
		{
			throw new IllegalArgumentException("Error: Penalty fee must be positive!");
		}
		penaltyFee=penaltyFee1;
	}
	
	protected void changeBalance(Double amount, String transactee) throws Exception
	{
		super.changeBalance(amount, transactee);
		if(amount + balance > 0.0)
		{
			addTransaction(-balance, transactee);
			currentPayment += -balance;
			this.balance = 0.0;
		}
		else if(amount > 0.0)
		{
			this.balance += amount;
			currentPayment += amount;
			addTransaction(amount, transactee);
		}
		else if(amount + balance < creditLimit)
		{
			throw new IllegalArgumentException("Error: You have exceeded the credit limit");
		}
		else
		{
			this.balance += amount;
			addTransaction(amount, transactee);
		}
		
	}
	
	protected void automatic() throws Exception
	{
		super.automatic();
		if(currentPayment < minimumMonthly)
		{
			this.balance += penaltyFee;
			addTransaction(penaltyFee, "Penalty Fee");
		}
		Double interest = this.balance*this.intRate/1200;
		addTransaction(interest, "Interest");
		this.balance += interest;
		currentPayment = 0.0;
		
		Double minPercent = -this.balance * minimumPercent/100;
		if(minPercent < minimumFixed)
		{
			minimumMonthly = minPercent;
		}
		else
		{
			minimumMonthly = minimumFixed;
		}
		
		intRate = globalInterest + interestOffset;
	}
	
	public String accountTypeToString()
	{
		return "Line of Credit Account";
	}
	
	public String getAccountInfo()
	{
		String temp = "";
		temp += super.getAccountInfo();
		temp += "\nCredit Limit: " + creditLimit;
		temp += "\nInterest Rate: " + (globalInterest + interestOffset);
		temp += "\nMinimum Monthly Payment: " + minimumMonthly;
		temp += "\nCurrent Payment: " + currentPayment;
		temp += "\nPenalty Fee for Not meeting Payments: " + penaltyFee;
		return temp;
	}
}
