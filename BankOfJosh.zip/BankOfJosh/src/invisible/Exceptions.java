package invisible;

public class Exceptions
{
	public static class DuplicateEmployeeException extends Exception
	{
		private static final long serialVersionUID = -2859189810051495180L;
		public DuplicateEmployeeException()
		{
			super();
		}
		public DuplicateEmployeeException(String message)
		{
			super(message);
		}
		public DuplicateEmployeeException(String message, Throwable cause) 
		{
			super(message, cause); 
		}		
		public DuplicateEmployeeException(Throwable cause)
		{ 
			super(cause); 
		} 
	}
}