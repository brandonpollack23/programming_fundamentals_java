package invisible;


import java.io.Serializable;
import java.util.*;


public class Customer implements Serializable
{
	private String firstName;
	private String lastName;
	private final Integer ssn;
	private Boolean isActive;
	private Boolean isEmployee;
	private ArrayList<Account> accounts;
	private Account activeAccount;
	private ArrayList<String> notices; //there needs to be methods for the customer to view these
	private final static long serialVersionUID = 1;
	
	public Customer(String firstName, String lastName, Integer ssn, Boolean isEmployee)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.ssn=ssn;
		this.isEmployee=isEmployee;
		accounts=new ArrayList<Account>();
		isActive = true;
		notices = new ArrayList<String>();
		notices.add("Welcome to BANKOFJOSH, Inc.!!!");
	}
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public Integer getSSN()
	{
		return ssn;
	}
	public Boolean getIsActive(){
		return isActive;
	}
	public Boolean isEmployee(){
		return isEmployee;
	}
	
	public ArrayList<Account> getAccounts()
	{
		return accounts;
	}
	
	public void setIsEmployee(Boolean isEmployee)
	{
		this.isEmployee = isEmployee;
	}
	
	public ArrayList<Transaction> getTransactions(Account a) 
	{
		return a.getTransactions();
	}
	
	public ArrayList<String> getNotices() 
	{
		return notices;
	}
	
	public void addNotice(String notice) 
	{
		this.notices.add(notice);
	}
	
	public void addAccount(Account a)
	{
		accounts.add(a);
	}
	
	public void flagTransaction(Transaction t)
	{
		t.flag();
	}
	
	public void accessAccount(Integer accIndex)
	{
		activeAccount = accounts.get(accIndex);
	}
	
	public void spendMoney(Double amount, String transactee) throws Exception //equivalent of using a debit card/credit card/check
	{
		if(!(activeAccount instanceof LOCAcc || activeAccount instanceof CheckingAcc))
		{
			throw new IllegalStateException("You may only spend money from LOC and Checking accounts");
		}
	}
	
	public void recieveMoney(Double amount, String transactee) throws Exception//Same as above, but receiving end
	{
		activeAccount.changeBalance(amount, transactee);
	}
	
	public void transferMoney(Double amount, Account from, Account to) throws Exception
	{
		if(from.isClosed || to.isClosed)
		{
			throw new IllegalArgumentException("Both accounts must be open");
		}
		else if(from instanceof LOCAcc)
		{
			throw new IllegalStateException("Cannot transfer money from LOC Account");
		}
		else if(amount < 0.0)
		{
			throw new IllegalArgumentException("amount must be positive");
		}
		else if(from == to)
		{
			throw new IllegalArgumentException("Error: Account cannot transfer to itself");
		}
		else
		{
			from.changeBalance(-amount, to.accNum.toString());
			to.changeBalance(amount, from.accNum.toString());
		}
	}
	
	public String accountListToString()
	{
		String temp = "\n \n";
		for (int i = 1; i <= accounts.size(); i++)
		{
			temp += i + ") ";
			// acc num to string, colon, type to string, balance, colon balance
			Account currentPrint = accounts.get(i-1);
			temp += currentPrint.getAccNum() + ": " + currentPrint.accountTypeToString() + " Acount is open: " + !currentPrint.isClosed() + ", balance: " + Math.abs(currentPrint.getBalance());
			temp += "\n";
		}
		return temp;
	}
	public void addAutoTransfer(Account accountToTransferFrom, Account accountToTransferTo, Double amount) throws Exception 
	{
		accountToTransferFrom.addAutoTransfer(accountToTransferTo, amount);
	}
	
	public String noticesToString()
	{
		String temp = "";
		temp += "Notices displayed below: \n\n";
		for (int i=0; i < notices.size(); i++)
		{
			temp += ("\n\n" + notices.get(i));
			temp += "\n_________________________________\n\n";
		}
		return temp;
	}
	
	public HashMap<Account, Double> getAutoTransfers(Account a)
	{
		return a.getAutoTransfers();
	}
	
	public void removeAutoTransfer(Account from, Account to)
	{
		from.removeAutoTransfer(to);
	}
}
