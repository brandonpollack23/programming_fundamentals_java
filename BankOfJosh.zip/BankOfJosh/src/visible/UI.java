package visible;

import invisible.Account;
import invisible.Customer;
import invisible.Data;
import invisible.Employee;
import invisible.LOCAcc;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class UI 
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		p("Is this your first time running this software? (enter y or n): ");
		while(true)
		{
			String answer = input.next();
			pl("");
			if(answer.equals("y"))
			{
				pl("initializing data...");
				Data.initialize();
				Data.save();
				break;
			}
			else if(answer.equals("n"))
			{
				Data.load();
				break;
			}
			else
			{
				pl("Error: please enter y or n");
			}
		}
		System.out.println("Welcome to Bank of Josh");
		
		while(true)
		{
			System.out.print("Enter your Social Security Number to log in, or 0 to exit: "); //add option to login as customer or employee
			Integer ssn = 0;
			try
			{
				ssn = new Integer(input.nextInt());
				pl("");
			}
			catch(InputMismatchException e)
			{
				pl("Error: please enter a valid SSN and try again.");
				continue;
			}
			System.out.println("Checking SSN...");
			if(ssn == 0)
			{
				Data.save();
				pl("Exiting...");
				break;
			}
			else
			{
				Employee e = Data.getEmployee(ssn);
				Customer c = Data.getCustomer(ssn);
				if(e == null && c == null)
				{
					System.out.println("Sorry, there is no user registered with that SSN.\n");
					continue;
				}
				else if(e == null && c != null)
				{
					System.out.println("Customer logging in...");
					customerInterface(c, input);
					continue;
				}
				else if(e != null && c != null)
				{
					System.out.println("Would you like to log in as a:\n1. Employee\n2. Customer");
					int choice = input.nextInt();
					pl("");
					if(choice == 2)
					{
						System.out.println("Customer logging in...");
						customerInterface(c, input);
						continue;
					}
				}
				if(e != null)
				{
					Role r = e.getRole();
					switch (r)
					{
					case TELLER:
						System.out.println("Teller logging in...");
						tellerInterface(e, input);
						break;
						
					case ACCOUNT_MANAGER:
						System.out.println("Account Manager logging in...");
						accountManagerInterface(e, input);
						break;
						
					case ACCOUNTANT:
						System.out.println("Accountant logging in...");
						accountantInterface(e, input);
						break;
						
					case AUDITOR:
						System.out.println("Auditor logging in...");
						auditorInterface(e, input);
						break;
						
					case OPERATIONS_MANAGER:
						System.out.println("Operations Manager logging in...");
						operationsManagerInterface(e, input);
						break;
					}
				}
			}
		}
	}
	
	public static void tellerInterface(Teller t, Scanner input)
	{
		pl("Welcome Teller!");
		
		Integer accNum = 0;
		while(true)
		{
			p("\nEnter a customer's account number to begin, or 0 to exit: ");
			
			try
			{
				accNum = new Integer(input.nextInt());
				pl("");
				if(accNum == 0)
				{
					break;
				}
				try
				{
					t.accessAccount(accNum);
				}
				catch(Exception e)
				{
					p("Error: there is no account registered with that number.\nPlease enter a valid account number and try again: ");
					continue;
				}
			}
			catch(InputMismatchException e)
			{
				p("Please enter a valid account number and try again: ");
				continue;
			}
			
			while(true)
			{
				pl("1. Account Info\n2. Withdraw\n3. Deposit\n4. Setup Automatic Transaction\n5. Switch Account\n6. End Transactions\nEnter the number of the option you want");
				String option = input.next();
				pl("");
				switch(option)
				{
				case "1":
					pl(t.getAccountInfo());
					break;
				case "2":
					pl("How much would you like to withdraw?");
					while(true)
					{
						try
						{
							Double amount = input.nextDouble();
							pl("");
							try
							{
								if(amount < 0.0)
								{
									throw new Exception("Error: You must enter a positive number");
								}
								t.changeBalance(-amount);
								break;
							}
							catch(Exception e)
							{
								pl(e.getMessage());
								p("Please enter a valid amount and try again: ");
							}
						}
						catch(Exception e)
						{
							p("Please enter a valid amount and try again: ");
						}
					}
					break;
				case "3":
					pl("How much would you like to deposit?");
					while(true)
					{
						try
						{
							Double amount = input.nextDouble();
							pl("");
							try
							{
								if(amount < 0.0)
								{
									throw new Exception("Error: You must enter a positive number");
								}
								t.changeBalance(amount);
							}
							catch(Exception e)
							{
								pl(e.getMessage());
								p("Please enter a valid amount and try again: ");
							}
							break;
						}
						catch(Exception e)
						{
							p("Please enter a valid amount and try again: ");
						}
					}
					break;
				case "4":
					a:
					while(true)
					{
						pl("Would you like to:\n1. Setup an automatic transaction\n2. Remove an automated transfer\n3. Exit\nEnter the number of the option you want.");
						String option2 = input.next();
						pl("");
						switch(option2)
						{
						case "1":
							while(true)
							{
								try
								{
									p("Enter the account number of the account you wish to setup an automated transfer with: ");
									Integer accountNum = input.nextInt();
									pl("");
									p("Enter the amount you wish to automatically transfer: ");
									Double amount;
									while(true)
									{
										try
										{
											amount = input.nextDouble();
											pl("");
											try
											{
												if(amount <= 0.0)
												{
													throw new Exception("Error: amount must be positive.");
												}
												break;
											}
											catch(Exception e)
											{
												pl(e.getMessage());
												p("Please enter a valid amount and try again: ");
											}
											t.setAutoTransaction(accountNum, amount);
										}
										catch(Exception e)
										{
											p("Enter a valid amount and try again: ");
										}
									}
									break;
								}
								catch(Exception e)
								{
									pl("Error: you must enter a valid account number.");
								}
							}
							break;
						case "2":
							pl(t.getAutoTransactions());
							p("Enter the account number of the auto-transaction to remove: ");
							Integer accNum2 = 0;
							while(true)
							{
								try
								{
									accNum2 = input.nextInt();
									pl("");
									t.removeAutoTransaction(accNum2);
									break;
								}
								catch(Exception e)
								{
									p("Please enter a valid account number and try again: ");
								}
							}
							break;
						case "3":
							break a;
						default:
							pl("Error: you must enter a number between 1 and 3.");
							break;
						}
					}
					
					break;
				case "5":
					p("Enter the new account's number: ");
					break;
				case "6":
					pl("Would you like to waive the transaction fee of " + -t.getTellerCharge() + "? (enter y or n)");
					while(true)
					{
						String option3 = input.next();
						pl("");
						if(option3.equals("n"))
						{
							t.chargeService();
							break;
						}
						else if(option3.equals("y"))
						{
							break;
						}
						p("Error: enter y or n: ");
					}
					Data.save();
					p("Enter a new customer's account number to begin, or 0 to exit: ");
					break;
				default:
					pl("Error: you must enter a number between 1 and 6.");
					continue;
				}
				break;
			}
		}
		Data.save();
	}
	
	public static void accountManagerInterface(AccountManager aM, Scanner input)
	{
		exit: 
		while(true)
		{
			pl("What is it would you would like to do?");
			pl("1) Access an existing customer's information");
			pl("2) Add a customer to the system.");
			pl("3) Add an account to a customer's profile");
			pl("4) View current loan cap and pool");
			pl("5) Exit");
			String option = input.next();
			pl("");
			switch (option)
			{
			case "1":
				pl("Enter the customer's SSN that you would like to access: ");
				while(true)
				{
					Integer customerSSN = input.nextInt();
					pl("");
					try
					{
						aM.accessCustomer(customerSSN);
					}
					catch(Exception e)
					{
						pl(e.getMessage());
						pl("please, try again");
						continue;
					}
					break;
				}
				pl(aM.getCustomerSSN().toString());
				pl(aM.getCustomer().getLastName() + "," + aM.getCustomer().getFirstName() + "\nSSN: " + aM.getCustomer().getSSN() + "\nEmployed here? " + aM.getCustomer().isEmployee() + "\nIs Active? " + aM.getCustomer().getIsActive());
				pl(aM.getCustomer().accountListToString());
				pl(aM.getCustomer().getAccounts().size() + 1 + ") Exit");
				pl("Select an account (You may edit LOC account credit limits)");
				while(true)
				{
					Integer selection = input.nextInt();
					pl("");
					if (selection > 0 && selection <= aM.getCustomer().getAccounts().size())
					{
						pl(aM.getCustomer().getAccounts().get(selection - 1).getAccountInfo());
						if (aM.getCustomer().getAccounts().get(selection - 1) instanceof LOCAcc);
						{
							pl("What would you like the new credit limit to be?");
							while(true)
							{
								Double newLimit = input.nextDouble();
								pl("");
								try
								{
									aM.setLOCCreditLimit(newLimit);
									break;
								}
								catch(Exception e)
								{
									pl(e.getMessage());
									pl("\nTry again");
								}
							}
						}
					}
					else if(selection == aM.getCustomer().getAccounts().size() + 1)
					{
						break;
					}
					else
					{
						pl("That is not an option, try again\n");
					}
				}
				break;
					
			case "2":
				pl("What is the new Customer's first name?");
				String firstName = input.next();
				pl("");
				pl("what is his or her last name?");
				String lastName = input.next();
				pl("");
//				pl("Are they an employee of the Bank of Josh? NOTE: Only put yes if they are already hired by the Operations Manager (y/n)");
				boolean isEmployee = false;
//				while(true)
//				{
//					String isEmployeeString = input.next();
//					pl("");
//					switch (isEmployeeString)
//					{
//					case "y":
//						isEmployee = true;
//						break;
//					case "n":
//						isEmployee = false;
//						break;
//					default:
//						pl("Please enter y or n");
//						continue;
//					}
//					break;
//				}
				
				pl("What is their Social Security Number?");
				Integer ssn;
				while(true)
				{
					try
					{
						ssn = input.nextInt();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}
				if (Data.getEmployee(ssn) != null) isEmployee = true;
				pl("What is the first account that they will use?");
				Account firstAccount = createNewAccount(input, aM);	
				try
				{
					aM.addCustomer(firstName, lastName, ssn, isEmployee, firstAccount);
					break;
				}
				catch(Exception e)
				{
					pl(e.getMessage());
				}
				break;
				
			case "3":
				pl("What customer would you like to add the account to?");
				Integer ssn2;
				while(true)
				{
					try
					{
						ssn2 = input.nextInt();
						pl("");
					}
					catch(Exception e)
					{
						pl(e.getMessage());
						continue;
					}
					try
					{
						aM.accessCustomer(ssn2);
						break;
					}
					catch(Exception e)
					{
						e.getMessage();
						continue;
					}
				}
				pl("What type of account would you like to add?");
				while(true)
				{
					try
					{
						Account newAccount = createNewAccount(input, aM);
						aM.addAccount(newAccount);
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
						continue;
					}
				}
				break;
				
			case "4":
				pl("The current global loan cap is" + aM.getGlobalLoanCap());
				pl("The current global loan pool is" + aM.getGlobalLoanPool());
				input.next();
				pl("");
				break;
				
			case "5":
				Data.save();
				break exit;
				
			default:
				pl("That is not an option!");	
				continue;
			}
		}
	}
	
	public static Account createNewAccount(Scanner input, AccountManager aM)
	{
		pl("1) Savings Account");
		pl("2) Certifice of Deposite Account");
		pl("3) Checking Account");
		pl("4) Loan Account");
		pl("5) Line of Credit Account");
		String accountType = "";
		while(true)
		{
			Double initialBalance;
			accountType = input.next();
			pl("");
			switch (accountType)
			{
			case "1":
				pl("What is the initial Balance of the Savings Account?");
				while(true)
				{
					try
					{
						initialBalance = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}
				try
				{
					return aM.createSavingsAcc(initialBalance);
				}
				catch(Exception e)
				{
					pl(e.getMessage());
				}
				break;
				
			case "2":
				pl("What is the inital Balance of the CD account?");
				while(true)
				{
					try
					{
						initialBalance = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}
				pl("What is length of this CD?");
				pl("1) 6 months");
				pl("2) 1 year");
				pl("3) 2 years");
				pl("4) 3 years");
				pl("5) 4 years");
				pl("6) 5 years");
				Integer length;
				while(true)
				{
					// STUB menu to select length of CD
					String CDlength = input.next();
					pl("");
					switch (CDlength)
					{
					case "1":
						length = 6;
						break;
					case "2":
						length = 12;
						break;
					case "3":
						length = 24;
						break;
					case "4":
						length = 36;
						break;
					case "5":
						length = 48;
						break;
					case "6":
						length = 60;
						break;
					default:
						pl("That is not a valid option");
						continue;
					}
					break;
				}
				try
				{
					return aM.createCDAcc(initialBalance, length);
					
				}
				catch(Exception e)
				{
					pl(e.getMessage());
				}
				break;
				
			case "3":
				pl("What is the initial balance of the Checking account?");
				while(true)
				{
					try
					{
						initialBalance = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}
				
				try
				{
					return aM.createCheckingAcc(initialBalance);
					
				}
				catch(Exception e)
				{
					pl(e.getMessage());
				}
				break;
				
			case "4":
				pl("What is the Loan amount?");
				Double initalLoan;
				while(true)
				{
					try
					{
						initalLoan = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}
				pl("What is the interest offset from global?");
				Double interestOffset;
				while(true)
				{
					try
					{
						interestOffset = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}
				pl("What will the minimum monthly payment be?");
				Double minimumMonthly;
				while(true)
				{
					try
					{
						minimumMonthly = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
					}
				}						
				try
				{
					return aM.createLoanAcc(initalLoan, interestOffset, minimumMonthly);
					
				}
				catch(Exception e)
				{
					pl(e.getMessage());
				}
				break;
				
			case "5":
				pl("What is the interest offset from global?");
				Double interestOffset2 = 0.0;
				while(true)
				{
					try
					{
						interestOffset2 = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
						continue;
					}
				}
				pl("what is the credit limit?");
				Double creditLimit;
				while(true)
				{
					try
					{
						creditLimit = input.nextDouble();
						pl("");
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
						continue;
					}
				}
				try
				{
					return aM.createLOCAcc(creditLimit, interestOffset2);
				}
				catch(Exception e)
				{
					pl(e.getMessage());
					continue;
				}
			default:
				pl("That isnt an option!");
				continue;
			}
			break;			
		}
		return null;			
	}
	public static void accountantInterface(Accountant a, Scanner input)
	{
		exitAI: while(true)
		{
			pl("Would you like to: ");
			pl("1) View global statistics");
			pl("2) Set a limit on maximum loans");
			pl("3) Exit");
			String option;
			while(true)
			{
				try
				{
					option = input.next();
					pl("");
					break;
				}
				catch(Exception e)
				{
					pl(e.getMessage());
					continue;
				}			
			}
			switch(option)
			{
			case "1":
				pl("Global Loan Cap: " + a.getGlobalLoanCap());
				pl("Global Loan Pool: " + a.getGlobalLoanPool());
				pl("LOC balance sums: " + a.getLOCBalanceSum());
				pl("LOC Credit Limit Sum: "+ a.getLOCCreditLimitSum());
				pl("Amount of money in checking: " + a.getTotalCheckingMoney());
				pl("Total money deposited in savings: " + a.getTotalSavingsMoney());
				break;
				
			case "2":
				pl("Enter the maximum (negative) value for total loans out (must be less than currently outstanding loans):");
				Double loanMax;
				while(true)
				{
					try
					{
						loanMax = input.nextDouble();
						pl("");
						a.setGlobalLoanCap(loanMax);
						break;
					}
					catch(Exception e)
					{
						pl(e.getMessage());
						continue;
					}
				}				
				break;
				
			case "3":
				Data.save();
				break exitAI;
			}
		}
	}
	
	public static void auditorInterface(Auditor a, Scanner input)
	{
		aI: while(true)
		{
			pl("Below is a list of accounts, select one to view it's transactions, and select one to overturn, 0 to exit");
			pl("IMPORTANT NOTE TO THE AUDITOR: if you overturn a tranfer, it is your responsibility to also overturn the recipient of the tranaction (unless they rightfully own that money)");
			pl(a.getAccountListToString());
			Integer option;
			while(true)
			{
				try
				{
					option = input.nextInt();
					pl("");
					if (option == 0) break aI;
					else a.accessAccount(a.getAccountList().get(option - 1));
					break;
				}
				catch(Exception e)
				{
					pl(e.getMessage());
					continue;
				}
			}
			pl(a.getAccount().transactionsToString());
			pl("Select a transaction to view, or press " + (a.getTransactions().size() + 1) + " to exit");
			outer: while(true)
			{
				try
				{
					option = input.nextInt();
					pl("");
					if (option - 1 < a.getTransactions().size())
					{
						pl(a.getTransactionInfo(a.getTransactions().get(option-1)));
						pl("Press 1 to overturn, 0 to exit");
						Integer choice;
						while(true)
						{
							choice = input.nextInt();
							pl("");
							if (choice == 0) break outer;
							if (choice == 1)
							{
								a.overturnTransaction(option-1);
								break outer;
							}
							else
							{
								pl("not a valid option");
								continue;
							}	
						}
					}
					else break outer;
				}
				catch(Exception e)
				{
					pl(e.getMessage());
					continue;
				}
			}
		}
	}
	
	public static void operationsManagerInterface(OperationsManager oM, Scanner input)
	{

		pl("Welcome Operations Manager!");
		b:
		while(true)
		{
			pl("Would you like to:\n1. Advance Time\n2. Set a Global Varible\n3. Check Global Variables\n4. Send a Notice\n5. Hire Employee\n6. Exit");
			String option = "";
			option = input.next();
			pl("");
			switch(option)
			{
			case "1":
				pl("Advancing Time 1 Month...");
				oM.advanceTime();
				break;
			case "2":
				while(true)
				{
					pl("Choose Variable Category:\n1. Savings Account\n2. CD Account\n3. Checking Account\n4. Loan Account\n5. LOC Account\6. Teller Service Charge\7. Exit");
					String option2 = input.next();
					pl("");
					switch(option2)
					{
					case "1":
						while(true)
						{
							pl("Choose Variable to Set:\n1. Savings Interest Rate\n2. Savings Service Fee\n3. Savings Balance Threshold\n4. Exit");
							String a = input.next();
							pl("");
							switch(a)
							{
							case "1":
								pl("Current Savings Interest Rate: " + oM.getSavingsInterestRate());
								while(true)
								{
									try
									{
										Double intRate = input.nextDouble();
										pl("");
										try
										{
											oM.setSavingsInterestRate(intRate);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid interest rate and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid interest rate and try again");
									}
								}
								break;
							case "2":
								pl("Current Savings Service Fee: " + oM.getSavingsServiceFee());
								while(true)
								{
									try
									{
										Double serviceFee = input.nextDouble();
										pl("");
										try
										{
											oM.setSavingsServiceFee(-serviceFee);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid service fee and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid service fee and try again");
									}
								}
								break;
							case "3":
								pl("Current Savings Balance Threshold: " + oM.getSavingsBalanceThreshold());
								while(true)
								{
									try
									{
										Double threshold = input.nextDouble();
										pl("");
										try
										{
											oM.setSavingsBalanceThreshold(threshold);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid threshold and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid threshold and try again");
									}
								}
								break;
							case "4":
								break;
							default:
								pl("Error. You must pick a number between 1 and 4.");
								continue;
							}
							break;
						}
						break;
					case "2":
						while(true)
						{
							pl("Choose Variable to Set:\n1. CD Interest Rates\n2. CD Close Threshold\n3. Exit");
							String a = input.next();
							pl("");
							switch(a)
							{
							case "1":
								pl("Current CD Interest Rates:\n" + "6 Months - " + oM.getCDGlobalInterestRates().get(6) + "%\n1 Year - "
							+ oM.getCDGlobalInterestRates().get(12) + "%\n2 Years - " + oM.getCDGlobalInterestRates().get(24) + "%\n3 Years - "
										+ oM.getCDGlobalInterestRates().get(36) + "%\n4 Years - " + oM.getCDGlobalInterestRates().get(48) + "%\n5 Years - "
							+ oM.getCDGlobalInterestRates().get(60) + "%");
								while(true)
								{
									try
									{
										pl("Enter the interest rates in increasing order from 6 months to 5 years seperated by spaces");
										Double[] intRates = new Double[6];
										for(int i = 0; i < 6; i++)
										{
											intRates[i] = input.nextDouble();
											pl("");
										}
										try
										{
											oM.setCDGlobalInterestRates(intRates);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter valid interest rates and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter valid interest rates and try again");
									}
								}
								break;
							case "2":
								pl("Current CD Close Threshold: " + oM.getCDCloseThreshold());
								while(true)
								{
									try
									{
										Double threshold = input.nextDouble();
										pl("");
										try
										{
											oM.setCDCloseThreshold(threshold);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid threshold and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid threshold and try again");
									}
								}
								break;
							case "3":
								break;
							default:
								pl("Error. You must pick a number between 1 and 3.");
								continue;
							}
							break;
						}
						break;
					case "3":
						while(true)
						{
							pl("Choose Variable to Set:\n1. Checking Service Charge\n2. Checking Service Threshold\n3. Checking Overdraft Fee\n4. Checking Overdraft Threshold\n5. Exit");
							String a = input.next();
							pl("");
							switch(a)
							{
							case "1":
								pl("Current Checking Service Charge: " + oM.getCheckingServiceCharge());
								while(true)
								{
									try
									{
										Double charge = input.nextDouble();
										pl("");
										try
										{
											oM.setCheckingServiceCharge(-charge);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid service charge and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid service charge and try again");
									}
								}
								break;
							case "2":
								pl("Current Checking Service Threshold: " + oM.getCheckingServiceThreshold());
								while(true)
								{
									try
									{
										Double threshold = input.nextDouble();
										pl("");
										try
										{
											oM.setCheckingServiceThreshold(threshold);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid threshold and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid threshold and try again");
									}
								}
								break;
							case "3":
								pl("Current Checking Overdraft Fee: " + oM.getCheckingOverdraftFee());
								while(true)
								{
									try
									{
										Double fee = input.nextDouble();
										pl("");
										try
										{
											oM.setCheckingOverdraftFee(-fee);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid fee and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid fee and try again");
									}
								}
								break;
							case "4":
								pl("Current Checking Overdraft Threshold: " + oM.getCheckingOverdraftThreshold());
								while(true)
								{
									try
									{
										Double threshold = input.nextDouble();
										pl("");
										try
										{
											oM.setCheckingOverdraftThreshold(threshold);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid threshold and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid threshold and try again");
									}
								}
								break;
							case "5":
								break;
							default:
								pl("Error. You must pick a number between 1 and 5.");
								continue;
							}
							break;
						}
						break;
					case "4":
						while(true)
						{
							pl("Choose Variable to Set:\n1. Loan Global Interest\n2. Loan Penalty Fee\n3. Exit");
							String a = input.next();
							pl("");
							switch(a)
							{
							case "1":
								pl("Current Loan Global Interest: " + oM.getLoanGlobalInterest());
								while(true)
								{
									try
									{
										Double interest = input.nextDouble();
										pl("");
										try
										{
											oM.setLoanGlobalInterest(interest);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid interest rate and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid interest rate and try again");
									}
								}
								break;
							case "2":
								pl("Current Loan Penalty Fee: " + oM.getLoanPenaltyFee());
								while(true)
								{
									try
									{
										Double fee = input.nextDouble();
										pl("");
										try
										{
											oM.setLoanPenaltyFee(-fee);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid fee and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid fee and try again");
									}
								}
								break;
							case "3":
								break;
							default:
								pl("Error. You must pick a number between 1 and 3.");
								continue;
							}
							break;
						}
						break;
					case "5":
						while(true)
						{
							pl("Choose Variable to Set:\n1. LOC Global Interest\n2. LOC Penalty Fee\n3. LOC Minimum Fixed Payment\n4. LOC Minimum Percentage Payment\n5. Exit");
							String a = input.next();
							pl("");
							switch(a)
							{
							case "1":
								pl("Current LOC Global Interest: " + oM.getLOCGlobalInterest());
								while(true)
								{
									try
									{
										Double interest = input.nextDouble();
										pl("");
										try
										{
											oM.setLOCGlobalInterest(interest);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid interest rate and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid interest rate and try again");
									}
								}
								break;
							case "2":
								pl("Current LOC Penalty Fee: " + oM.getLOCPenaltyFee());
								while(true)
								{
									try
									{
										Double fee = input.nextDouble();
										pl("");
										try
										{
											oM.setLOCPenaltyFee(-fee);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid fee and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid fee and try again");
									}
								}
								break;
							case "3":
								pl("Current LOC Minimum Fixed Payment: " + oM.getLOCMinimumFixed());
								while(true)
								{
									try
									{
										Double minFixed = input.nextDouble();
										pl("");
										try
										{
											oM.setLOCMinimumFixed(minFixed);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid payment and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid payment and try again");
									}
								}
								break;
							case "4":
								pl("Current LOC Minimum Percentage Payment: " + oM.getLOCMinimumPercent());
								while(true)
								{
									try
									{
										Double minPercent = input.nextDouble();
										pl("");
										try
										{
											oM.setLOCMinimumPercent(minPercent);
											break;
										}
										catch(Exception e)
										{
											pl(e.getMessage());
											pl("Please enter a valid percentage and try again");
										}
									}
									catch(Exception e)
									{
										pl("Please enter a valid percentage and try again");
									}
								}
								break;
							case "5":
								break;
							default:
								pl("Error. You must pick a number between 1 and 5.");
								continue;
							}
							break;
						}
						break;
					case "6":
						pl("Current Teller Charge: " + oM.getTellerCharge());
						while(true)
						{
							try
							{
								Double charge = input.nextDouble();
								pl("");
								try
								{
									oM.setTellerCharge(-charge);
									break;
								}
								catch(Exception e)
								{
									pl(e.getMessage());
									pl("Please enter a valid charge and try again");
								}
							}
							catch(Exception e)
							{
								pl("Please enter a valid charge and try again");
							}
						}
						break;
					case "7":
						break;
					default:
						pl("Error: enter a number between 1 and 7.");
						continue;
					}
					break;
				}
				break;
			case "3":
				System.out.println("Savings Interest: " + oM.getSavingsInterestRate() + "%\nSavings Service Fee $" + -oM.getSavingsServiceFee() + "\nSavings Balance Threshold $"
						+ oM.getSavingsBalanceThreshold() + "\n6 Months CD Interest Rate " + oM.getCDGlobalInterestRates().get(6) + "%\n1 Year CD Interest Rate "
						+ oM.getCDGlobalInterestRates().get(12) + "%\n2 Year CD Interest Rate " + oM.getCDGlobalInterestRates().get(24) + "%\n3 Year CD Interest Rate "
						+ oM.getCDGlobalInterestRates().get(36) + "%\n4 Year CD Interest Rate " + oM.getCDGlobalInterestRates().get(48) + "%\n5 Year CD Interest Rate "
						+ oM.getCDGlobalInterestRates().get(60) + "%\nCD Close Threshold $" + oM.getCDCloseThreshold() + "\nChecking Service Charge $" + -oM.getCheckingServiceCharge()
						+ "\nChecking Service Threshold $" + oM.getCheckingServiceThreshold() + "\nChecking Overdraft Fee $" + -oM.getCheckingOverdraftFee()
						+ "\nOverdraft Threshold $" + -oM.getCheckingOverdraftThreshold()
						+ "\nLoan Global Interest " + oM.getLoanGlobalInterest()
						+ "%\nLoan Penalty Fee $" + -oM.getLoanPenaltyFee() + "\nLOC Global Interest " + oM.getLOCGlobalInterest() + "%\nLOC Penalty Fee $"
						+ -oM.getLOCPenaltyFee() + "\nLOC Minimum Fixed Payment $" + oM.getLOCMinimumFixed() + "\nLOC Minimum Percent Payment " + oM.getLOCMinimumPercent() + "%\nTeller Service Charge $"
						+ -oM.getTellerCharge());
				break;
			case "4":
				pl("Enter what you want your notice to say on one line.");
				String notice = input.nextLine();
				notice = input.nextLine();
				pl("");
				while(true)
				{
					pl("Choose which customer to send this notice too (enter a number below):");
					ArrayList<Customer> customers = oM.getCustomerList();
					int i = 0;
					for(Customer c: customers)
					{
						i++;
						pl(i + ". " + c.getFirstName() + " " + c.getLastName());
					}
					try
					{
						Integer customerIndex = input.nextInt() - 1;
						pl("");
						oM.sendNotice(customers.get(customerIndex), notice);
						break;
					}
					catch(Exception e)
					{
						pl("Error: enter valid number");
					}
				}
				break;
			case "5":
				pl("What position will the new employee hold (enter the number of your choice)?\n1. Teller\n2. Account Manager\n3. Accountant\n4. Auditor\n5. Operations Manager");
				String option5;
				Role role;
				while(true)
				{
					option5 = input.next();
					switch(option5)
					{
					case "1":
						role = Role.TELLER;
						break;
					case "2":
						role = Role.ACCOUNT_MANAGER;
						break;
					case "3":
						role = Role.ACCOUNTANT;
						break;
					case "4":
						role = Role.AUDITOR;
						break;
					case "5":
						role = Role.OPERATIONS_MANAGER;
						break;
					default:
						pl("Error: enter a number between 1 and 5");
						continue;
					}
					break;
				}
				pl("What is the new employees social security number?");
				Integer ssn;
				while(true)
				{
					try
					{
						ssn = input.nextInt();
						try
						{
							oM.addEmployee(ssn, role);
							if(Data.getCustomer(ssn) != null) Data.getCustomer(ssn).setIsEmployee(true);
							break;
						}
						catch(Exception e)
						{
							pl(e.getMessage());
							p("Please enter a valid social security number and try again: ");
						}
					}
					catch(Exception e)
					{
						p("Please enter a valid social security number and try again: ");
					}
				}
				break;
			case "6":
				Data.save();
				break b;
			default:
				pl("Error: enter a number between 1 and 6.");
				continue;
			}
			
		}
	
	}
	
	public static void customerInterface(Customer c, Scanner input)
	{
		while(true)
		{
			Integer option;
			pl(c.getLastName() + "," + c.getFirstName() + "\nSSN: " + c.getSSN() + "\nEmployed here? " + c.isEmployee() + "\nIs Active? " + c.getIsActive());
			pl(c.accountListToString());
			pl(c.getAccounts().size()+1 + ") Set up Autotransfer");
			pl(c.getAccounts().size()+2 + ") Transfer Funds");
			pl(c.getAccounts().size()+3 + ") View Notices (" + c.getNotices().size() +")");
			pl(c.getAccounts().size()+4 + ") Exit");
			option = input.nextInt();
			pl("");
			if (((boolean) (option == (c.getAccounts().size() + 4))))
			{
				break;
			}
			else if ((boolean) (option == (c.getAccounts().size() + 1)))
			{
				pl("From what account would you like to autotransfer?");
				boolean selectedValue = false;
				do
				{
					option = input.nextInt();		
					pl("");
					if (option < 0 || option > c.getAccounts().size())
					{
						pl("Error: That is not a valid account, try again");
					}
					else selectedValue = true;
				}while (!(selectedValue));
				Account accountToTransferFrom = c.getAccounts().get(option-1);
				
				pl("\n\nTo which account?");
				selectedValue = false;
				
				do
				{
					option = input.nextInt();
					pl("");
					if (option < 0 || option > c.getAccounts().size())
					{
						pl("Error: That is not a valid account, try again");
					}
					else selectedValue = true;
				}while (selectedValue = false);
				Account accountToTransferTo = c.getAccounts().get(option-1);
				
				try
				{
					if (accountToTransferFrom == accountToTransferTo)
					{
						throw new IllegalStateException("Error: Cannot Transfer to yourself!");
					}
					else 
					{
						pl("\n\nHow much would you like to transfer?");
						Double amount = input.nextDouble();
						pl("");
						
						//add that autotransfer
						c.addAutoTransfer(accountToTransferFrom, accountToTransferTo, amount);
					}
				}				
				catch(Exception e)
				{
					pl(e.getMessage());
				}
			}
			else if ((boolean) (option == (c.getAccounts().size() + 2)))
			{
				System.out.println("\n\nFrom which account would you like to transfer? (select the number from above)");
				boolean selectedValue = false;
				do
				{				
					option = input.nextInt();
					pl("");
					if (option < 1 || option > c.getAccounts().size())
					{
						System.out.println("Invalid Selection, try again");
					}
					else selectedValue = true;
				} while (selectedValue == false);
				Account accountToTransferFrom = c.getAccounts().get(option - 1);
				
				//logic for transfering money
				System.out.println("\n\nTo which account?");
				selectedValue = false;
				do 
				{
					option = input.nextInt();
					pl("");
					if (option < 1 || option > c.getAccounts().size())
					{
						System.out.println("Invalid Selection, try again");
					}
					else selectedValue = true;
						
				}while (selectedValue == false);
				Account accountToTransferTo = c.getAccounts().get(option-1);
				try
				{
					if (accountToTransferFrom == accountToTransferTo)
					{
						throw new IllegalStateException("Cannot Transfer to yourself!");
					}
					else 
					{
						pl("\n\nHow much would you like to transfer?");
						while(true)
						{
							try
							{
								Double amount = input.nextDouble();
								pl("");
								try
								{
									c.transferMoney(amount, accountToTransferFrom, accountToTransferTo);
									break;
								}
								catch(Exception e)
								{
									pl(e.getMessage());
									p("Please enter a valid amount and try again: ");
								}
							}
							catch(Exception e)
							{
								p("Please enter a valid amount and try again: ");
							}
						}
					}
				}				
				catch(IllegalStateException e)
				{
					pl(e.getMessage());
				}
			}
			else if (option == (c.getAccounts().size() + 3))
			{
				pl(c.noticesToString());
				input.next();
				pl("");
			}
			else if(option > 0 && option <= c.getAccounts().size())
			{
				pl(c.getAccounts().get(option-1).getAccountInfo());
				pl("1) View this accounts transactions");
				pl("2) View this accounts autotransfers for removal");
				pl("any other integer) exit");
				Integer innerOption = input.nextInt();
				pl("");
				if (innerOption == 1)
				{
					pl(c.getAccounts().get(option-1).transactionsToString());
					pl("if you would like to mark any of these as fradulent, enter its number\n" +
							"otherwise, enter any other integer");
					Integer innerOption1 = input.nextInt();
					pl("");
					if(innerOption1 > 0 && innerOption1 <= c.getTransactions(c.getAccounts().get(option-1)).size())
					{
						c.flagTransaction(c.getTransactions(c.getAccounts().get(option-1)).get(innerOption1-1));
					}
				}
				else if(innerOption == 2)
				{
					pl(c.getAccounts().get(option-1).transactionsToString());
					pl("enter the number to remove the autotransfer, other will exit");
					innerOption = input.nextInt();
					pl("");
					if (innerOption > 0 && innerOption < c.getAutoTransfers(c.getAccounts().get(option-1)).size())
					{
						c.removeAutoTransfer(c.getAccounts().get(option-1), c.getAccounts().get(innerOption - 1));
					}
				}
			}
			else
			{
				pl("Error: Invalid choice, try again, please\n");
			}
				
		}
		Data.save();
	}
	
	public static void p(String s)
	{
		System.out.print(s);
	}
	
	public static void pl(String s)
	{
		System.out.println(s);
	}
}
