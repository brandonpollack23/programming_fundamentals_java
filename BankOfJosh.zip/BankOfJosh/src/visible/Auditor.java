package visible;


import invisible.Account;
import invisible.Transaction;

import java.util.ArrayList;


public interface Auditor 
{
	String getAccountListToString();
	void accessAccount(Integer accNum) throws Exception;
	Account getAccount();
	ArrayList<Transaction> getTransactions();
	String getTransactionInfo(Transaction trans);
	void overturnTransaction(Integer transIndex);
	ArrayList<Account> getAccountList();
	void accessAccount(Account a);
}
