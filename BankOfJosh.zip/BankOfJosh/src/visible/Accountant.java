package visible;

public interface Accountant 
{
	Double getGlobalLoanCap();
	Double getGlobalLoanPool();
	Double getLOCBalanceSum();
	Double getLOCCreditLimitSum();
	Double getTotalCheckingMoney();
	Double getTotalSavingsMoney();
	void setGlobalLoanCap(Double cap) throws Exception;
}
