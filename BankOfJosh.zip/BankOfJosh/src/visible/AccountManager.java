package visible;

import invisible.*;



public interface AccountManager 
{
	void accessCustomer(Integer customerSSN);
	Integer getCustomerSSN();
	Customer getCustomer();
	void setLOCCreditLimit(Double newLimit) throws Exception;
	void addCustomer(String firstName, String lastName, Integer ssn, Boolean isEmployee, Account firstAccount) throws Exception;
	void addAccount(Account newAccount) throws Exception;
	Double getGlobalLoanCap();
	Double getGlobalLoanPool();
	SavingsAcc createSavingsAcc(Double initialBalance) throws Exception;
	CDAcc createCDAcc(Double initialBalance, Integer length) throws Exception;
	CheckingAcc createCheckingAcc(Double initialBalance) throws Exception;
	LoanAcc createLoanAcc(Double initalLoan, Double interestOffset, Double minimumMonthly) throws Exception;
	LOCAcc createLOCAcc(Double creditLimit, Double interestOffset2) throws Exception;
}
