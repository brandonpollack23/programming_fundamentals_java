package visible;


import invisible.Customer;

import java.util.ArrayList;
import java.util.HashMap;


public interface OperationsManager 
{
	void advanceTime();
	Double getSavingsInterestRate();
	void setSavingsInterestRate(Double intRate) throws Exception;
	Double getSavingsServiceFee();
	void setSavingsServiceFee(Double d) throws Exception;
	Double getSavingsBalanceThreshold();
	void setSavingsBalanceThreshold(Double threshold) throws Exception;
	HashMap<Integer, Double> getCDGlobalInterestRates();
	void setCDGlobalInterestRates(Double[] intRates) throws Exception;
	Double getCDCloseThreshold();
	void setCDCloseThreshold(Double thresh) throws Exception;
	Double getCheckingServiceCharge();
	void setCheckingServiceCharge(Double d) throws Exception;
	Double getCheckingServiceThreshold();
	void setCheckingServiceThreshold(Double threshold) throws Exception;
	Double getCheckingOverdraftFee();
	void setCheckingOverdraftFee(Double d) throws Exception;
	Double getCheckingOverdraftThreshold();
	void setCheckingOverdraftThreshold(Double threshold) throws Exception;
	Double getLoanGlobalInterest();
	void setLoanGlobalInterest(Double interest) throws Exception;
	Double getLoanPenaltyFee();
	void setLoanPenaltyFee(Double d) throws Exception;
	Double getLOCGlobalInterest();
	void setLOCGlobalInterest(Double interest);
	Double getLOCPenaltyFee();
	void setLOCPenaltyFee(Double d) throws Exception;
	Double getLOCMinimumFixed();
	void setLOCMinimumFixed(Double minFixed) throws Exception;
	Double getLOCMinimumPercent();
	void setLOCMinimumPercent(Double minPercent) throws Exception;
	Double getTellerCharge();
	void setTellerCharge(Double d);
	ArrayList<Customer> getCustomerList();
	void sendNotice(Customer customer, String notice);
	void addEmployee(Integer ssn, Role role);
}
