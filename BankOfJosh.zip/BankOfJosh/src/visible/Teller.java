package visible;


public interface Teller //Teller should only get information about things that can change due to changeBalance
{
	void accessAccount(Integer accNum) throws Exception;
	String getAccountInfo();
	void changeBalance(Double d) throws Exception;
	void setAutoTransaction(Integer accountNum, Double amount) throws Exception;
	String getAutoTransactions();
	void removeAutoTransaction(Integer accNum2);
	Double getTellerCharge();
	void chargeService();
}
